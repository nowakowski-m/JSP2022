# Zadanie 1

K = (('król', {2:'królewna', 1:['córka', 'wróbel']},'5'),('żółw', 'pies'))

word = K[0][1].get(1)

print(word[1])